<template>
	<view>
		<view class="newly-added-view">
			<view class="newly-added" @click="calDis">按钮</view>
			<view class="map_ans"> <text>两地相距{{dis}}km</text> </view>
		</view>
	</view>
</template>

<script setup>
	import {
		reactive,
		toRefs
	} from "vue"

	const data = reactive({
		la1: 27.923659,
		/*经度*/
		lo1: 120.659421,
		/*纬度*/
		la2: 28.015791,
		lo2: 120.667449,
		dis: 0,
	})
	const {
		la1,
		lo1,
		la2,
		lo2,
		dis
	} = toRefs(data)

	function calDis() {
		// 计算两个经纬度之间的距离
		var La1 = data.la1 * Math.PI / 180.0;
		var La2 = data.la2 * Math.PI / 180.0;
		var La3 = La1 - La2;
		var Lb3 = data.lo1 * Math.PI / 180.0 - data.lo2 * Math.PI / 180.0;
		data.dis = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(La3 / 2), 2) + Math.cos(La1) * Math.cos(La2) * Math.pow(
			Math.sin(Lb3 / 2), 2)));
		data.dis = data.dis * 6378.137; //地球半径
		data.dis = Math.round(data.dis * 10000) / 10000;
	}
</script>

<style>
</style>
