<template>
	<view @touchmove.navtive.stop="aaa">
		<!-- <DemoTantan></DemoTantan> -->
		<SwipeCard :scard="cards" />
	</view>
</template>

<script setup>
	import {onMounted,reactive,toRefs,ref} from 'vue'
	import SwipeCard from '../components/card/views/swipe_backend.vue'
	import Flash from '../components/flash-sale/flash-sale.vue'
	import DemoTantan from '../components/card/views/demo-tantan.vue';
	const db = wx.cloud.database()
	
	onMounted(()=>{
		// const but_data = wx.getMenuButtonBoundingClientRect()
		// search_data.S_height = but_data.height
		// search_data.S_top = but_data.top
		// search_data.S_left = but_data.left - 30
		// search_data.Custom_height = but_data.height + but_data.top + 5
		goods()
		aaa()
		// getAll()
	})
	
	// 请求数据
	const result = reactive({seckill:[],cards:[]})
	const {seckill,cards} = toRefs(result)
	// async function getAll(){
	// 	  // 1，获取数据的总个数
	// 	  let count = await db.collection('goods').count()
	// 	  count = count.total
	// 	  // 2，通过for循环做多次请求，并把多次请求的数据放到一个数组里
	// 	  let all = []
	// 	  for (let i = 0; i < count; i += 20) { //自己设置每次获取数据的量
	// 		let list = await db.collection('num').skip(i).get()
	// 		all = all.concat(list.data);
	// 	  }
	// 	  // 3,把组装好的数据一次性全部返回
	// 	  console.log('返回的数据',all)
	// }
	
	async function goods(){
		
		// 轮播
		// const banner = await db.collection('banner').get()
		// 秒杀
		// const seckill = await db.collection('seckill').field({seckill_time:false}).get()
		// 测试
		const seckill = await db.collection('goods').get()
		// cards
		const cards = await db.collection('goods').get()
		let count = await db.collection('goods').where({shelves:true}).count()
		count = count.total
		// 2，通过for循环做多次请求，并把多次请求的数据放到一个数组里
		let all = []
		for (let i = 0; i < count; i += 10) { //自己设置每次获取数据的量
					let list = await db.collection('goods').skip(i).where({shelves:true}).limit(10).get()
					all = all.concat(list.data);
		}
		shuffle(all)
		result.cards = all
		// 商品数据
		// const card = await db.collection('goods').where({shelves:true}).limit(10).field({goods_cover:true,goods_price:true,goods_title:true,sold:true,video_url:true}).orderBy('sold','desc').get()
		Promise.all([seckill,cards])
		.then(res=>{
			console.log(res)
			console.log("test")
			// result.banner = res[0].data
			// result.seckill = res[1].data
			// result.card = res[2].data
			result.seckill = res[0].data
			// result.cards = res[1].data
		})
		.catch(err=>{
			console.log(err)
		})
	}
	
	function shuffle(arr) {
	  var i = arr.length, t, j;
	  while (i) {
	    j = Math.floor(Math.random() * i--);
	    t = arr[i];
	    arr[i] = arr[j];
	    arr[j] = t;
	  }
	}
	
	function aaa(){
		return;
	}
</script>

<style lang="scss">
	page{
		width: 100% !important;  
		height: 100% !important;  
		display: flex !important;  
		align-items: center !important;  
	}
</style>

