<template>
	<view class="center">
		<view class="center_top">
			<view class="mask">
				<!-- <image src="/static/detail/weidenglu.svg" mode="aspectFit"></image> -->
			</view>
			<!-- <view ></view> -->
		</view>
		<view class="center_box_bg">
			<view class="profily" v-if="exist">
				<view class="base">
					<image :src="user_infor.avatarUrl" mode="aspectFit" class="profile_my"></image>
					<text style="font-weight: bold; font-size: 35rpx;">{{user_infor.nickName}}</text>
				</view>
				<view class="order_status">
					<view class="status" @click="CuisineUp(item.link)" v-for="(item,key) in list_data.status">
						<image class="icon" :src="item.url" mode="aspectFill"></image>
						<text>{{item.name}}</text>
					</view>
				</view>
			</view>
			<view class="profily" v-else="!exist" @click="goLogin">
				<view class="base">
					<image src="/static/detail/weidenglu.svg" mode="aspectFit" class="profile_my"></image>
					<view>
						<text>点击此处登陆！</text>
					</view>
				</view>
				<view class="order_status">
					<view class="status" v-for="(item,key) in list_data.status">
						<image class="icon" :src="item.url" mode="aspectFill"></image>
						<text>{{item.name}}</text>
					</view>
				</view>
			</view>
			<view class="baiban"></view>
			<view class="center_menu">
				<view class="menu_item" v-for="(item,key) in list_data.menus">
					<image :src="item.icon" mode="aspectFill"></image>
					<text>{{item.name}}</text>
				</view>
			</view>
		</view>
	</view>
	<!-- 登陆弹窗 -->
	<Login />
</template>

<script setup>
	import {reactive,toRefs,watch} from 'vue'
	import {onShow} from '@dcloudio/uni-app'
	import Login from '../components/login-view.vue'
	
	const list_data = reactive({
		status: [{
				key: 1,
				name: '我的收藏',
				url: '../../static/my-icon/heart-2-fill.png',
				link:'/pages/favorite/favorite'
			},
			{
				key: 2,
				name: '发布美食',
				url: '../../static/my-icon/upload-cloud-2-fill.png',
				link:'/pages/cuisine-upload/cuisine-upload'
			},
			{
				key: 3,
				name: '前端保存',
				url: '../../static/my-icon/heart-2-fill.png',
				link:'/pages/index/swipe-test'
			},
			{
				key: 4,
				name: '设置',
				url: '../../static/my-icon/settings-fill.png',
				link:'/pages/cuisine-upload/cuisine-upload'
			}
		],
		menus: [
			// {
			// 	name: '我的收藏',
			// 	icon: '../../static/fumou-center-template/5.png',
			// 	key: 1,
			// },
			// {
			// 	name: '地址管理',
			// 	icon: '../../static/fumou-center-template/6.png',
			// 	key: 2,
			// },
			// {
			// 	name: '尺码对照表',
			// 	icon: '../../static/fumou-center-template/7.png',
			// 	key: 3,
			// },
			{
				name: '帮助中心',
				icon: '../../static/my-icon/question-fill.svg',
				key: 4,
			},
			{
				name: '意见反馈',
				icon: '../../static/my-icon/mail-fill.svg',
				key: 5,
			},
			{
				name: '关于我们',
				icon: '../../static/my-icon/information-fill.svg',
				key: 6,
			}

		]
	})
	
	
	// 查询是否登陆
	onShow(()=>{
		staTus()
	})
	const user = reactive({user_infor:{},exist:false})
	const {user_infor,exist} = toRefs(user)
	function staTus(){
		const user_data = wx.getStorageSync('user_infor')//取出本地缓存的用户信息
		if(user_data){
			user.exist = true
			user.user_infor = user_data
		}else{
			user.exist = false
		}
	}
	import {login_user} from '@/Acc-config/answer.js'
	// 调用登陆弹窗
	function goLogin(){
		login_user.show = true
		console.log("click")
	}
	function jump(){
		wx.switchTab({
			url:'/pages/index/index'
		})
	}
	
	// 监听登陆是否成功，成功则重新取收藏和购物车的数据
	watch(()=>login_user.response,(newVal,oldVal)=>{
		staTus()
	})
	
	// Cuisine upload
	function CuisineUp(link){
		if(user.exist){
			wx.navigateTo({
				url:link
			})
			console.log(1)
		}else{
			login_user.show = true
		}
	}
	
	
	// export default {
	// 	data() {
	// 		return {
	// 			status: [{
	// 					key: 1,
	// 					name: '待发货',
	// 					url: '../../static/fumou-center-template/one.png'
	// 				},
	// 				{
	// 					key: 2,
	// 					name: '待收货',
	// 					url: '../../static/fumou-center-template/2.png'
	// 				},
	// 				{
	// 					key: 3,
	// 					name: '待评价',
	// 					url: '../../static/fumou-center-template/3.png'
	// 				},
	// 				{
	// 					key: 4,
	// 					name: '全部订单',
	// 					url: '../../static/fumou-center-template/4.png'
	// 				}
	// 			],
	// 			menus: [{
	// 					name: '我的收藏',
	// 					icon: '../../static/fumou-center-template/5.png',
	// 					key: 1,
	// 				},
	// 				{
	// 					name: '地址管理',
	// 					icon: '../../static/fumou-center-template/6.png',
	// 					key: 2,
	// 				},
	// 				{
	// 					name: '尺码对照表',
	// 					icon: '../../static/fumou-center-template/7.png',
	// 					key: 3,
	// 				},
	// 				{
	// 					name: '帮助中心',
	// 					icon: '../../static/fumou-center-template/8.png',
	// 					key: 4,
	// 				},
	// 				{
	// 					name: '意见反馈',
	// 					icon: '../../static/fumou-center-template/9.png',
	// 					key: 5,
	// 				},
	// 				{
	// 					name: '关于我们',
	// 					icon: '../../static/fumou-center-template/10.png',
	// 					key: 6,
	// 				}

	// 			]
	// 		};
	// 	},
	// 	methods: {

	// 	},
	// 	computed: {

	// 	}
	// }
</script>

<style lang="scss">
	page {
		height: 100%;
	}

	.profily,
	.profily_header {
		border-radius: 12px;
	}

	.center {
		height: 100%;

		&_top {
			height: 25%;
			// background: url('../../static/fumou-center-template/header.jpg') no-repeat 0% 50%;
			// background-size: cover;

			// background: #E6E6E6;
			.mask {
				// background: rgba(0, 0, 0, .4);
				background: #eb7970;
				height: 100%;
			}
		}

		&_box_bg {
			background: #F9F9F9;
			position: relative;

			.profily {
				position: absolute;
				width: 90%;
				// border:1px solid #F7F7F7;
				margin: 0 auto;
				top: -100upx;
				left: 5%;
				background: #FEFEFE;
				padding: 35upx;
				box-sizing: border-box;
				box-shadow: 0px 2px 5px #EDEDED;
			}
		}
	}

	.base {
		display: flex;
		align-items: center;
		border-bottom: 2px solid #F6F6F6;
		padding-bottom: 35upx;
		position: relative;
		.profily_header {
			height: 120upx;
			width: 120upx;
		}
		.profile_my {
			height: 120upx;
			width: 120upx;
		}

		text {
			margin-left: 20px;
			font-size: 30upx;
		}
		
		// image{
		// 	position: absolute;
		// 	height: 40upx;
		// 	width: 40upx;
		// 	right: 0px;
		// 	top:0px;
		// }
	}

	.order_status {
		display: flex;
		justify-content: space-between;
		margin-top: 35upx;

		.status {
			width: 140upx;
			font-size: 24upx;
			text-align: center;
			letter-spacing: .5px;
			display: flex;
			flex-direction: column;
			.icon {
				width: 50upx;
				height: 50upx;
				margin: 0 auto;
				margin-bottom: 5px;
				
			}
		}
	}

	.baiban {
		background: #FEFEFE;
		height: 300upx;
	}

	.center_menu {
		width: 100%;
		display: inline-block;

		.menu_item {
			font-size: 28upx;
			letter-spacing: 1px;
			padding: 14px 5%;
			background: #FEFEFE;
			overflow: hidden;
			box-sizing: border-box;
			display: flex;
			align-items: center;
			position: relative;
			border-bottom: 1px solid #EFEFEF;

			&:hover {
				background: #F6F6F6 !important;
			}

			&::after {
				content: '';
				width: 30upx;
				height: 30upx;
				position: absolute;
				right: 5%;
				background: url('../../static/fumou-center-template/right.png') no-repeat;
				background-size: 100%;
			}

			text:nth-of-type(1) {
				margin-left: 10px;
			}

			image {
				width: 40upx;
				height: 40upx;
			}

			&:nth-of-type(4) {
				margin-top: 10px;
			}
		}
	}
	.my-page{
		height: 300rpx;
		/* background: #4CD964; */
		background: linear-gradient(to bottom, #e94b37 25%, #e59f95 100%);
		position: relative;
		padding-top: 100rpx;
	}
	.my-name image{
		display: block;
		width: 100rpx;
		height: 100rpx;
		border-radius: 50%;
		margin-bottom: 10rpx;
	}
	.my-name{
		color: #FFFFFF;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		height: 230rpx;
		font-size: 33rpx;
		z-index: 9;
		position: absolute;
		left: 0;
		right: 0;
	}
	.shuibo-img{
		position: absolute;
		bottom: 0;
		left: 0;
		width: 100%;
		height: 170rpx;
		/* z-index: 99; */
		mix-blend-mode: screen;
	}
	/* 我的订单 */
	.my-order{
		margin-top: 20rpx;
		padding: 0 20rpx;
	}
	.my-order-title image{
		width: 30rpx;
		height: 30rpx;
		display: block;
		margin-left: 10rpx;
	}
	.my-order-title{
		display: flex;
		justify-content: space-between;
	}
	.my-order-title view:nth-child(1){
		font-weight: bold;
	}
	.my-order-title view:nth-child(2){
		font-size: 25rpx;
		color: #cfcfcf;
	}
	.more{
		display: flex;
		align-items: center;
	}
	.order-state image{
		display: block;
		width: 50rpx;
		height: 50rpx;
		margin-bottom: 10rpx;
	}
	.order-state{
		display: flex;
		align-items: center;
		justify-content: space-between;
		margin-top: 30rpx;
	}
	.order-state view{
		display: flex;
		align-items: center;
		flex-direction: column;
		color: #4f4f4f;
	}
	/* 其他功能 */
	.my-other{
		background-color: #FFFFFF;
		margin: 50rpx 20rpx 20rpx 20rpx;
		box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;
		border-radius: 6rpx;
		padding: 0 10rpx;
		color: #828282;
	}
	.my-other image{
		display: block;
		width: 35rpx;
		height: 35rpx;
		margin-right: 20rpx;
	}
	.my-other view{
		display: flex;
		align-items: center;
		padding: 30rpx 0;
	}
	.my-other view:nth-child(2){
		border-bottom: 1rpx solid #e0e0e0;
		border-top: 1rpx solid #e0e0e0;
	}
	.my-other text{
		flex: 1;
	}
	.my-other-deta{
		width: 30rpx !important;
		height: 30rpx !important;
		margin: 0 !important;
	}
</style>
