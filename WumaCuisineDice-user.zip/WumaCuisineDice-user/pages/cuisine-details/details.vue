<template>
	<view class="detailPage">
<!-- 		<view class="cuisineBanner">
			<view class="uni-margin-wrap">
				<swiper class="swiper" circular current=0 indicator-dots=true autoplay=true interval=2000 duration=200>
					<swiper-item v-for="(item,index) in cuisine_banner" :key="index">
						<image :src="img.image" mode="aspectFill"></image>
					</swiper-item>
				</swiper>
			</view>
		</view> -->
		<view class="swiper-view">
			<swiper :duration="1000" :circular="true" @change="changeCurrent">
				<block v-for="(item,index) in result.cuisine_banner" :key="index">
					<swiper-item>
						<view class="swiper-item">
							<image class="imageurl" :src="item.image" mode="aspectFill" @click="preView(item.image)"></image>
						</view>
					</swiper-item>
				</block>
			</swiper>
			<!-- 自定义指示点 -->
			<view class="point">{{current}}/{{ban_length}}</view>
		</view>
		<view class="detail-view">
			<view class="titleDetailView">
				<view class="detail-title">{{cuisine_name}}</view>
				<view class="detail-price">{{cuisine_price}}</view>
			</view>
		
			<view class="cardDetailView">
				<view class='cuisineTypeView'>
					<text class="cuisineType">{{category}}</text>
				</view>
				<view class='cuisineTypeView'>
					<text class="dianName">店名：{{dian_name}}</text>
				</view>
			</view>
			
			<view style="height: 5px;"></view>
			
			<view class="cardDetailView">
				<view class='cuisineTypeView'>
					<text class="dianContact">联系电话：{{cuisine_contact}}</text>
				</view>
	<!-- 			<view class='cuisineTypeView'>
					<text class="dianName">店名：{{dian_name}}</text>
				</view> -->
			</view>

<!-- 			<view class='cuisineText'>
				<text>店名：{{dian_name}}</text>
			</view>
			<view class='cuisineText'>
				<text>联系电话：{{cuisine_contact}}</text>
			</view>
			<view>
				<text class='cuisineText'>地址：{{cuisine_address}}</text>
			</view> -->
		</view>
<!-- 		<view>
			<button class="gotoButton" @click="openMap(latitude, longitude,cuisine_name)">到这儿去</button>
		</view> -->
		<!-- 底部 -->
		<view class="manage">
			<text @click="preView1(result.dian_cover)">查看店面图</text>
			<text @click="openMap(latitude, longitude,cuisine_name)">导航去这儿</text>
		</view>
	</view>

</template>

<script setup>
	import {
		onLoad
	} from '@dcloudio/uni-app'
	// import {
	// 	reactive,
	// 	toRefs
	// } from "vue"
	import {
		Map,
		Feedback
	} from '../../Acc-config/map-view.js'
	import {
		Login
	} from '../../Acc-config/logic.js'
	import {Upload} from '../../Acc-config/media.js'
	
	function preView(image){
		let arr = []
		result.cuisine_banner.forEach(item=>{arr.push(item.image)})
		new Upload().preview(image,arr)
	}
	
	function preView1(image){
		let arr = []
		result.dian_banner.forEach(item=>{arr.push(item.image)})
		new Upload().preview(image,arr)
	}

	import {watch,ref,reactive,toRefs,onBeforeUnmount} from 'vue'
	// const props = defineProps({goods:Object,seckill:Array})
	// import {ORDER} from '../../../Acc-config/place-order.js'
	
	// 轮播图片数量
	const ban_length = ref(0)
	const current = ref(1)
	function changeCurrent(e){
		current.value = e.detail.current + 1
	}
	

	//请求数据，传值
	const db = wx.cloud.database()
	const result = reactive({
		cuisine_id: '',
		category: '',
		cuisine_banner: [],
		cuisine_name: '',
		dian_name: '',
		cuisine_contact: '',
		cuisine_price: '',
		cuisine_address: '',
		dian_cover: '',
		dian_banner: [],
		longitude: 0,
		latitude: 0
	})
	const {
		cuisine_id,
		cuisine_banner,
		cuisine_name,
		dian_name,
		category,
		cuisine_address,
		cuisine_contact,
		cuisine_price,
		dian_cover,
		dian_banner,
		longitude,
		latitude
	} = toRefs(result)

	function openMap(latitude, longitude, title, address) {
		// new Map().openmap1()
		new Map().openmap(latitude, longitude, title, address)
		// console.log('hello1')
		new Feedback('点到了').toast()
		// console.log(props.scard[0].goods_title)
	}
	
	function previewDian(image,arr) {
		wx.previewImage({
			current: image, // 当前显示图片的http链接
			urls: arr // 需要预览的图片http链接列表['htt.xxx.jpg','htt.xxx.jpg']
		})
	}	

	onLoad((event) => {
		result.cuisine_id = event.cuisine_id
		const cuisine = db.collection('goods').doc(event.cuisine_id).get()
		Promise.all([cuisine])
			.then(async res => {
				console.log(res)
				result.cuisine_name = res[0].data.cuisine_name
				result.category = res[0].data.category
				result.cuisine_banner = res[0].data.cuisine_banner
				result.dian_name = res[0].data.dian_name
				result.cuisine_contact = res[0].data.cuisine_contact
				result.cuisine_price = res[0].data.cuisine_price
				result.cuisine_address = res[0].data.cuisine_address
				result.dian_cover = res[0].data.dian_cover
				result.dian_banner = res[0].data.dian_banner
				result.longitude = res[0].data.longitude
				result.latitude = res[0].data.latitude
				ban_length.value = res[0].data.cuisine_banner.length
				// console.log(result.cuisine_banner)
			})
			.catch(err => {
				console.log(err)
			})
	})

	// function swiper {
	// 	changeIndicatorDots(e) {
	// 		this.indicatorDots = !this.indicatorDots
	// 	}
	// 	changeAutoplay(e) {
	// 		this.autoplay = !this.autoplay
	// 	}
	// 	intervalChange(e) {
	// 		this.interval = e.target.value
	// 	}
	// 	durationChange(e) {
	// 		this.duration = e.target.value
	// 	}
	// }
</script>

<style>
	page{background-color: #FFFFFF;}

	.uni-margin-wrap {
		width: 690rpx;
		width: 100%;
	}

	.swiper {
		height: 700rpx;
	}

	.swiper-item {
		display: block;
		height: 300rpx;
		line-height: 300rpx;
		text-align: center;
	}

	.textPart {
		/* margin-top: 20px; */
	}

	.cuisineText {
		margin: 10rpx 30rpx;
		font-size: 40rpx;
	}

	.cuisineType {
	  font-weight: 500;
	  color: white;
	  background-color: #f0ad4e;
	  border-radius: 3px;
	  font-size: 30rpx;
	  padding: 2px;
	  line-height: 25rpx;
	}
	.dianName {
	  font-weight: 500;
	  color: white;
	  background-color: #4aadf9;
	  border-radius: 3px;
	  font-size: 30rpx;
	  padding: 2px;
	  line-height: 25rpx;
	}
	.dianContact{
	  font-weight: 500;
	  color: white;
	  background-color: #5ecb50;
	  border-radius: 3px;
	  font-size: 30rpx;
	  padding: 2px;
	  line-height: 25rpx;
	}
	.cuisineTypeView{
	  padding-left: 10px;
	  line-height: 25rpx;
	}

	.typeText,
	.priceText {
		text-align: center;
	}
	.cardDetailView{
	  display: flex;
	  flex-direction: row;
	  align-items: baseline;
	  line-height: 25rpx;
	  margin-top: 15px;
	  /* padding-left: 10px; */
	  vertical-align:top;
	}
	.titleDetailView{
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		align-items: baseline;
		line-height: 25rpx;
		/* margin-top: 15px; */
		/* padding-left: 10px; */
		vertical-align:baseline;
	}
	.cuisinePrice {
		width: 200rpx;
		font-weight: 600;
		color: white;
		background-color: green;
		border-radius: 3px;
		font-size: 40rpx;
		padding: 20rpx;
		line-height: 25rpx;
	}
	.Real-price{
		color: #b1865b;
		font-weight: bold;
	}	
	.gotoButton {
		width: 200rpx;
		height: 100rpx;
		margin-top: 70rpx;
	}
	
	.imageurl {
		width: 100%;
		height: 700rpx !important;
	}
	
	.swiper-view {
		height: 700rpx !important;
		position: relative;
	}
	swiper{
		height: 700rpx !important;
	}
	.point{
		position: absolute;
		bottom: 10rpx;
		right: 20rpx;
		background-color: #333333;
		opacity: 0.5;
		color: #FFFFFF;
		font-size: 25rpx;
		width: 100rpx;
		height: 50rpx;
		border-radius: 50rpx;
		line-height: 50rpx;
		text-align: center;
	}
	/* 价格 */
	.price-view{
		background-color: #FFFFFF;
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 0 20rpx;
		height: 100rpx;
	}
	.price-view view:nth-child(1){
		color: #e9445a;
		font-size: 40rpx;
		font-weight: bold;
	}
	.price-view view:nth-child(2){
		color: #b1b2b5;
	}
	/* 秒杀 */
	.seckill{
		background-color: #e74e64;
		padding: 10rpx 20rpx;
		color: #ffffff;
	}
	.seckill-flex{
		display: flex;
		align-items: center;
	}
	.seckill-Center{
		flex: 1;
		padding: 0 20rpx;
	}
	.seckill-top{
		padding-bottom: 10rpx;
		font-size: 25rpx;
	}
	.seckill-top text:nth-child(1){
		background-color: #f6d3db;
		padding: 5rpx 15rpx;
		color: #ea4163;
		border-radius: 5rpx;
	}
	.price-spike{
		font-size: 35rpx;
		font-weight: bold;
	}
	.ori-price{
		text-decoration: line-through;
		color: #f1b0be;
	}
	.se-time{
		display: flex;
		align-items: center;
	}
	.se-time text{
		margin-left: 10rpx;
	}
	.se-time text:nth-child(odd){
		background-color: #eb6578;
		padding: 2rpx 10rpx;
		border-radius: 10rpx;
	}
	/* 底部 */
	.manage{
		position: fixed;
		bottom: 0;
		right: 0;
		left: 0;
		display: flex;
		justify-content: space-between;
	}
	.manage text{
		width: 50%;
		text-align: center;
		padding: 20rpx 0;
	}
	.manage text:nth-child(1){
		background-color: antiquewhite;
	}
	.manage text:nth-child(2){
		background-color: aliceblue;
	}
	/* 标题 */
	.detail-title{
		padding: 20rpx;
		line-height: 25rpx;
		font-size: 60rpx;
		font-weight: 700;
		/* background-color: #FFFFFF; */
		margin-top: 10px;
	}
	.detail-view{
		background-color: #FFFFFF;
		/* display: flex; */
		/* justify-content: flex-start; */
	}
	.detail-price{
		padding-right: 20rpx;
		line-height: 25rpx;
		font-size: 50rpx;
		font-weight: 750;
		/* background-color: #FFFFFF; */
		margin-top: 10px;
		color: #b1865b;
	}
</style>
