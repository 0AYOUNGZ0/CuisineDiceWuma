<template>
	<!-- Upload image cuisine -->
	<view class="goods-top goods-video">
		<view class="image-title" >
				<text>发布美食名称和图片</text>
		</view>
		<view><input type="text" v-model="cover.goods_title" placeholder="请输入美食名称" placeholder-class="pl-text"/></view>
		<view class="goods-image">
			<view class="upload-Image" v-if="cover.sto_image.length > 0" v-for="(item,index) in cover.sto_image" :key="index">
				<image :src="item.image" mode="aspectFill" @click="preView(item.image)"></image>
				<image src="/static/detail/cuowu.png" mode="widthFix" @click="deleteImg(index)"></image>
			</view>
			<view @click="upImage"><image src="/static/detail/shuxing-img.png" mode="aspectFill"></image></view>
		</view>
	</view>
	
	<!-- Upload image dianMian -->
	<view class="goods-top goods-video">
		<view class="image-title" >
				<text>发布店面名称和店面外景图片</text>
		</view>
		<view><input type="text" v-model="coverdian.dian_title" placeholder="请输入店面名称" placeholder-class="pl-text"/></view>
		<view class="goods-image">
			<view class="upload-Image" v-if="coverdian.dian_sto_image.length > 0" v-for="(item,index) in coverdian.dian_sto_image" :key="index">
				<image :src="item.image" mode="aspectFill" @click="preViewD(item.image)"></image>
				<image src="/static/detail/cuowu.png" mode="widthFix" @click="deleteImgDian(index)"></image>
			</view>
			<view @click="upImageDian"><image src="/static/detail/shuxing-img.png" mode="aspectFill"></image></view>
		</view>
	</view>

	<!-- Upload short video -->
<!-- 	<view class="goods-top goods-video">
		<view class="video-title">
			<text>上传美食相关短视频(可选)</text>
			<image src="/static/detail/shanchu.svg" v-if="video.sto_video != ''" @click="video.sto_video = ''"></image>
		</view>
		<view class="goods-image" v-if="video.sto_video == ''">
			<view><image src="/static/detail/shuxing-img.png" mode="aspectFill" @click="upVideo"></image></view>
		</view>
		<video v-if="video.sto_video != ''" :src="video.sto_video" object-fit="cover"></video>
	</view> -->
	
	<!-- Pick a category -->
	<view class="specs-view">
		<picker mode="selector" :range="sortArray" range-key="sort_name" @change="changeEnd">
		<view class="sort-title specs-title">
			<text>选择美食标签</text>
			<text>{{sort_value}}</text>
			<image src="/static/detail/xiangyou-jiantou.svg" mode="widthFix"></image>
		</view>
		</picker>
	</view>

	<!-- longitude 经度 & latitude 纬度-->
	<view class="goods-top">
		<view class="image-title" >
				<text>上传地点经纬度</text>
		</view>
		<view><input type="text" v-model="others.longitude" placeholder="请输入经度" placeholder-class="pl-text"/></view>
		<view><input type="text" v-model="others.latitude" placeholder="请输入纬度" placeholder-class="pl-text"/></view>
		<view>
			<button type="primary" @click="getWS()" style="background-color: cornflowerblue;">获取位置</button>
		</view>
	</view>

	<!-- Price -->
	<view class="goods-top">
		<view class="image-title">
			<text>价格描述</text>
			<!-- <input type="number" v-model="others.price" placeholder="请输入价格" placeholder-class="I-style" cursor-spacing="50"> -->
		</view>
		<view>
			<input type="text" v-model="others.price" placeholder="请输入价格描述,如“10块钱三串”" placeholder-class="I-style" cursor-spacing="50" style="font-weight: normal;"/>
		</view>
	</view>

	<!-- item detail -->
<!-- 	<view class="goods-top">
		<view class="image-title"><text>美食详情</text></view>
		<view><input type="text" v-model="others.intro" placeholder="请输入美食介绍(不超过150字,可选)" placeholder-class="pl-text"/></view>
		<view class="detail-image" v-if="detail.sto_detail.length > 0" v-for="(item,index) in detail.sto_detail" :key="index">
			<image :src="item.image" mode="widthFix" @click="previewData(item.image)"></image>
			<image src="/static/detail/cuowu.png" mode="widthFix" @click="deleteData(index)"></image>
		</view>
		<view class="specs-image">
			<image src="/static/detail//kongshangp.jpeg" mode="center" @click="upDetail"></image>
		</view>
	</view> -->
	
	<!-- Contact -->
	<view class="goods-top">
		<view class="image-title" >
				<text>上传联系方式(可选)</text>
		</view>
		<!-- <view><input type="text" v-model="others.address" placeholder="请输入地址详细名称" placeholder-class="pl-text"/></view> -->
		<view><input type="text" v-model="others.contact" placeholder="请输入联系方式" placeholder-class="pl-text"/></view>
	</view>
	
	<!-- Address -->
	<view class="goods-top">
		<view class="image-title" >
				<text>上传地址(可选)</text>
		</view>
		<view><input type="text" v-model="others.address" placeholder="请输入地址详细名称" placeholder-class="pl-text"/></view>
	</view>

	
	<!-- Button -->
	<view style="height: 300rpx;"></view>
	<view class="newly-added-view back">
		<view class="newly-added" @click="subMit">添加美食</view>
	</view>
	
	
	
</template>

<script setup>
	import {watch,reactive,toRefs,onMounted} from 'vue'
	import {Map} from '@/Acc-config/map-view.js'
	
	// 价格、地址、联系方式、大众点评链接
	const others = reactive({price:'', intro:'', address:'', contact:'', link:'', longitude:'', latitude:''})
	const {price, intro, address, contact, link, longitude, latitude} = toRefs(others)
	
	// 上传美食图片
	import {Feedback,Upload} from '@/Acc-config/media.js'
	const cover = reactive({goods_title:'',sto_image:[]})
	async function upImage(){
		const local = await new Upload().image(9)
		local.forEach(item=>{
			cover.sto_image.push({image:item.tempFilePath})
		})
	}
	
	// 删除美食图片
	function deleteImg(index){
		cover.sto_image.splice(index,1)
	}
	
	//获取地址
	function getWS(){
		wx.getLocation({
		 type: 'gcj02', //返回可以用于 wx.openLocation 的经纬度
		 // type: 'wgs84',
		 success (res) {
		   others.latitude = res.latitude
		   others.longitude = res.longitude
		 }
		 // new Feedback('经纬度获取成功！',success).toast()
		})
	}
	
	// 预览图片
	function preView(image){
		let arr = []
		cover.sto_image.forEach(item=>{arr.push(item.image)})
		new Upload().preview(image,arr)
	}
	
	// 上传店面图片
	const coverdian = reactive({dian_title:'',dian_sto_image:[]})
	async function upImageDian(){
		const local = await new Upload().image(9)
		local.forEach(item=>{
			coverdian.dian_sto_image.push({image:item.tempFilePath})
		})
	}
	
	// 删除店面图片
	function deleteImgDian(index){
		coverdian.dian_sto_image.splice(index,1)
	}
	
	// 预览店面图片
	function preViewD(image){
		let arr = []
		coverdian.dian_sto_image.forEach(item=>{arr.push(item.image)})
		new Upload().preview(image,arr)
	}
	
	// 上传短视频
	const video = reactive({sto_video:''})
	async function upVideo(){
		const local = await new Upload().image(1,'video')
		video.sto_video = local[0].tempFilePath
	}
	
	// 所属分类
	import {inIt} from '@/Acc-config/init.js'
	onMounted(async()=>{
		let DB = await inIt()
		const res = await DB.database().collection('goods_sort').field({_openid:false}).get()
		sortdata.sortArray = res.data
	})
	const sortdata = reactive({
		sortArray:[],
		sort_value:'',
		sort_id:'',//分类的id，用于提交数据时对选中的分类下的quantity++
	})
	const {sortArray,sort_value} = toRefs(sortdata)
	
	function changeEnd(e){
		sortdata.sort_value = sortdata.sortArray[e.detail.value].sort_name
		sortdata.sort_id = sortdata.sortArray[e.detail.value]._id
	}
	
	// 上传详情图
	const detail = reactive({sto_detail:[]})
	async function upDetail(){
		const local = await new Upload().image(9)
		local.forEach(item=>{
			detail.sto_detail.push({image:item.tempFilePath})
		})
	}
	// 删除详情图
	function deleteData(index){
		detail.sto_detail.splice(index,1)
	}
	// 预览详情图
	function previewData(image){
		let arr = []
		detail.sto_detail.forEach(item=>{arr.push(item.image)})
		new Upload().preview(image,arr)
	}
	
	
	// 提交校验
	function subMit(){
		switch(true)
		{
			case cover.goods_title == '' : new Feedback('请填写美食名称').toast()
			break;
			case coverdian.dian_title == '' : new Feedback('请填写店面名称').toast()
			break;
			case cover.sto_image.length == 0 : new Feedback('请上传美食图片').toast()
			break;
			case coverdian.dian_sto_image.length == 0 : new Feedback('请上传店面图片').toast()
			break;
			case sortdata.sort_value == '' : new Feedback('请选择分类').toast()
			break;
			case others.price == '' : new Feedback('请输入价格').toast()
			break;
			case others.longitude == '' : new Feedback('请输入经度').toast()
			break;
			case others.latitude == '' : new Feedback('请输入纬度').toast()
			break;
			// case others.address == '' : new Feedback('请输入地址').toast()
			// break;
			// case others.contact == '' : new Feedback('请输入联系方式').toast()
			// break;
			// case detail.sto_detail.length == 0 : new Feedback('请上传详情图').toast()
			// break;
			default:database()
		}
	}
	
	// 提交到数据库
	async function database(){
		wx.showLoading({title: '上传中', mask:true})
		// 1.上传横幅
		let res_banner = await new Upload().multi(cover.sto_image,'image')
		
		// // 2.上传详情图
		// let res_detail = await new Upload().multi(detail.sto_detail,'image')
		// // 3.短视频，存在短视频再上传
		// let res_video = video.sto_video == '' ? '' : await new Upload().cloud(video.sto_video)
		
		// 4.上传店面图
		let res_banner_dian = await new Upload().multi(coverdian.dian_sto_image,'image')
		let obj = {
			cuisine_name:cover.goods_title,
			cuisine_banner:res_banner,
			cuisine_cover:res_banner[0].image,
			// video_url:res_video,
			dian_name:coverdian.dian_title,
			dian_banner:res_banner_dian,
			dian_cover:res_banner_dian[0].image,
			// intoduction:others.intro,
			// images:res_detail,
			shelves:false,
			longitude:Number(others.longitude),
			latitude:Number(others.latitude),
			category:sortdata.sort_value,
			cuisine_price:others.price,
			cuisine_address:others.address,
			cuisine_contact:others.contact,
			// reference:others.link
		}
		try{
			let DB = await inIt()
			const res = await DB.database().collection('goods').add({data:obj})
			// // 对选择的分类下的数量++
			const _ = DB.database().command
			await DB.database().collection('goods_sort').doc(sortdata.sort_id).update({data:{quantity:_.inc(1)}})
			new Feedback('上传成功','success').toast()
		}catch(e){
			console.log(e)
			new Feedback('提交失败').toast()
		}
	}
	
</script>

<style>
page{
	background-color: #f2f2f2;
}
.goods-top{
	background-color: #FFFFFF;
	padding: 20rpx;
	margin: 40rpx 20rpx;
	border-radius: 8rpx;
}
.pl-text{
	font-weight: 150;
}
.goods-top input{
	padding: 30rpx 0;
	font-weight: bold;
}
.goods-image{
	display: flex;
	flex-wrap: wrap;
}
.goods-image view{
	width: calc(33.3% - 5rpx*2);
	height: 200rpx;
	margin: 5rpx;
}
.goods-image image{
	width: 100%;
	height: 100%;
	display: block;
	border-radius: 7rpx;
}
.upload-Image {
	position: relative;
}
.upload-Image image:nth-child(2){
	width: 30rpx !important;
	height: 30rpx !important;
	position: absolute;
	top: 0;
	right: 0;
}
/* 视频 */
.goods-video{
	margin-top: 40rpx;
}
.video-title{
	display: flex;
	justify-content: space-between;
	align-items: center;
	font-weight: bold;
	font-size: large;
	margin-bottom: 20rpx;
}
.video-title image{
	width: 35rpx;
	height: 35rpx;
	display: block;
}
.goods-video video{
	height: 400rpx;
	width: 100%;
}
/* 所属分类 */
.sort-title text:nth-child(1){
	flex: 1;
}
.sort-title text:nth-child(2){
	padding-right: 20rpx;
}
/* 价格，库存 */
.price-stock view{
	display: flex;
	align-items: center;
	justify-content: space-between;
	padding: 20rpx;
}
.price-stock view:nth-child(1){
	padding-bottom: 20rpx;
}
.price-stock text:nth-child(1){
	/* flex: 1; */
}
.price-stock input{
	/* padding: 0 20rpx; */
	/* text-align: right; */
}
.I-style{
	color: #a8a8a8;
	/* font-size: 28rpx !important; */
}
/* 规格 */
.specs-view{
	background-color: #FFFFFF;
	margin: 40rpx 20rpx;
	border-radius: 8rpx;
}
.specs-title image{
	width: 35rpx;
	height: 35rpx;
	display: block;
}
.specs-title{
	display: flex;
	align-items: center;
	justify-content: space-between;
	padding: 20rpx;
	font-weight: bold;
}

.specs-image{
	padding: 20rpx;
}
.detail-image{
	position: relative;
}
.detail-image image:nth-child(1){
	width: 100%;
	height: 100%;
	display: block;
}
.detail-image image:nth-child(2){
	width: 40rpx;
	height: 40rpx;
	position: absolute;
	top: 5rpx;
	right: 5rpx;
}
/* 底部 */
.back{
	background-color: #fafafa !important;
	padding-top: 10rpx !important;
}
.image-title{
	display: flex;
	justify-content: space-between;
	align-items: center;
	font-weight: bold;
	font-size: large;
	margin-bottom: 0rpx;
}
</style>