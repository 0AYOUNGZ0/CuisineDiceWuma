<template>
  <view class="flex-center-in-cube" >
	<view
      v-if="actionName != ''"
      style="
        color: #fff;
        background: rgba(0, 0, 0, 0.9);
        padding: 10px 20px;
        font-size: 24px;
        position: absolute;
		border-radius: 5px;
        z-index: 999;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
      "
    >
      {{ actionName }}
    </view>
    <fly-card
      @onDragMove="onCardDragMove"
      @onDragStop="onCardDragStop"
      @onThrowDone="onCardThrowDone"
      :cardWidth="640"
      :cardHeight="920"
      :throwTriggerDistance="100"
      dragDirection="all"
      :hasShadow="true"
	  :borderRadius="18"
	  :hasBorder="false"
    >
      <template #firstCard style="width: 100%; height: 100%;">
        <view v-if="props.scard[0]" class="tantanCard" @click="juMp(props.scard[0]._id)">
          <image
            :src="props.scard[0].cuisine_cover"
            style="width: 100%; height: 80%"
            mode="aspectFill"
          />
		  <view class="cardWrapper">
			  <view>
				  <text class="cardTitle">
					  <!-- {{cards[0].title}} -->
					  {{props.scard[0].cuisine_name}}
				  </text>
			  </view>
			  <view class="cardDetailView">
				  <view class="cardTypeView">
					  <text class="cardType">
						  <!-- {{cards[0].type}} -->
						  {{props.scard[0].category}}
					  </text>
				  </view>
				  <view class="cardAvgView">
					  <text class="cardAvg">
						  <!-- 人均{{cards[0].avgPrice}}¥ -->
						  {{props.scard[0].cuisine_price}}
					  </text>
				  </view>
				  <view class="cardDisView">
					  <text class="cardDis">
						  <!-- {{cards[0].distance}} -->
						  <!-- {{props.scard[0].cuisine_address}} -->
						  {{card_data.distance}}KM
					  </text>
				  </view>
			  </view>
		  </view>
        </view>
      </template>
      <template #secondCard style="width: 100%; height: 100%" >
        <view v-if="props.scard[1]" class="tantanCard" @click="juMp(props.scard[1]._id)">
          <image
            :src="props.scard[1].cuisine_cover"
            style="width: 100%; height: 80%"
            mode="aspectFill"
          />
		  <view class="cardWrapper">
			  <view>
				  <text class="cardTitle">
					  <!-- {{cards[1].title}} -->
					  {{props.scard[1].cuisine_name}}
				  </text>
			  </view>
			  <view class="cardDetailView">
				  <view class="cardTypeView">
					  <text class="cardType">
						  <!-- {{cards[1].type}} -->
						  {{props.scard[1].category}}
					  </text>
				  </view>
				  <view class="cardAvgView">
					  <text class="cardAvg">
						  <!-- 人均{{cards[1].avgPrice}}¥ -->
						  {{props.scard[1].cuisine_price}}
					  </text>
				  </view>
				  <view class="cardDisView">
					  <text class="cardDis">
						  <!-- {{cards[1].distance}} -->
						  <!-- {{props.scard[1].cuisine_address}} -->
						  {{card_data.distance}}KM
					  </text>
				  </view>
			  </view>
		  </view>
        </view>
      </template>
      <template #thirdCard style="width: 100%; height: 100%">
        <view v-if="props.scard[2]" class="tantanCard" @click="juMp(props.scard[1]._id)">
          <image
            :src="props.scard[2].cuisine_cover"
            style="width: 100%; height: 80%"
            mode="aspectFill"
          />
		  <view class="cardWrapper">
			  <view>
				  <text class="cardTitle">
					  <!-- {{cards[2].title}} -->
					  {{props.scard[2].cuisine_name}}
				  </text>
			  </view>
			  <view class="cardDetailView">
				  <view class="cardTypeView">
					  <text class="cardType">
						  <!-- {{cards[2].type}} -->
						  {{props.scard[2].category}}
					  </text>
				  </view>
				  <view class="cardAvgView">
					  <text class="cardAvg">
						  <!-- 人均{{cards[2].avgPrice}}¥ -->
						  {{props.scard[2].cuisine_price}}
					  </text>
				  </view>
				  <view class="cardDisView">
					  <text class="cardDis">
						  <!-- {{cards[2].distance}} -->
						  <!-- {{props.scard[2].cuisine_address}} -->
						  {{card_data.distance}}KM
					  </text>
				  </view>
			  </view>
		  </view>
        </view>
      </template>
    </fly-card>
  </view>
</template>

<script setup>
import FlyCard from "../components/FlyCard.vue";
import image1 from "../assets/cat Medium.jpeg";
import image2 from "../assets/cute fox Medium.jpeg";
import image3 from "../assets/cute fox2 Medium.jpeg";
import image4 from "../assets/cute fox3 Medium.jpeg";
import image5 from "../assets/rabbit Medium.jpeg";
// import {onMounted,reactive,toRefs} from 'vue'
import {onLoad,onReachBottom,onShow} from '@dcloudio/uni-app'
import {onMounted,watch,reactive,toRefs,ref,onBeforeUnmount,toRaw,nextTick} from 'vue'
import {ORDER,SHCART} from '../../../../Acc-config/place-order.js'
// let props_new = defineProps({goods_id:String,collection:Number,sku_data:Array,goods:Object})

import {Map,Feedback} from '../../../../Acc-config/map-view.js'	

const props = defineProps({scard:Array})

// onLoad((event)=>{
// 	console.log("dsds")
// 	getdistance()
// })

const card_data = reactive({
      actionName: "",
      cards: [
        {
          image: image1,
		  title: "陈辉鱼圆",
		  type: "小吃面食",
		  avgPrice: "30",
		  distance: "245m",
		  longitude: 120.667877,
		  latitude: 28.018295,
		  address: "超人气韩料店 芝士给的很大方，满满的能拉丝  弄堂小店",
        },
        {
          image: image2,
		  title: "西施豆腐",
		  type: "小吃面食",
		  avgPrice: "7",
		  distance: "1.2km",
		  longitude: 120.668138,
		  latitude: 28.017316,
		  address: "装修很有特色，复古小巷风 个人感觉肉质还可以 价格挺划算",
        },
        {
          image: image3,
		  title: "童姥阁北京烤鸭",
		  type: "北京烤鸭",
		  avgPrice: "88",
		  distance: "534m",
		  longitude: 120.668884,
		  latitude: 28.018648,
		  address: "装修很有特色，复古小巷风",
        },
        {
          image: image4,
          title: "酒隐食肆日式融合料理",
		  type: "日本料理",
		  avgPrice: "94",
		  distance: "2.4km",
		  longitude: 120.664861,
		  latitude: 28.016544,
		  address: "装修很有特色，复古小巷风",
        },
        {
          image: image5,
          title: "卤枝一家老成都串串香",
		  type: "特色小吃",
		  avgPrice: "20",
		  distance: "3.5km",
		  longitude: 120.664945,
		  latitude: 28.017178,
		  address: "装修很有特色，复古小巷风",
        }
      ],
	  distance: "....."
})
const {actionName,cards,distance} = toRefs(card_data)

function getdistance(){
	wx.getLocation({
		 type: 'gcj02', //返回可以用于 wx.openLocation 的经纬度
		 // type: 'wgs84',
		 success (res) {
		 //   const latitude_ = res.latitude
		 //   const longitude = res.longitude
			console.log(res.latitude);
		    console.log(res.longitude);
			console.log('hello!')
			var La1 = props.scard[0].latitude * Math.PI / 180.0;
			var La2 = res.latitude * Math.PI / 180.0;
			var La3 = La1 - La2;
			var Lb3 = props.scard[0].longitude * Math.PI / 180.0 - res.longitude * Math.PI / 180.0;
			card_data.distance = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(La3 / 2), 2) + Math.cos(La1) * Math.cos(La2) * Math.pow(
				Math.sin(Lb3 / 2), 2)));
			card_data.distance = card_data.distance * 6378.137; //地球半径
			card_data.distance = (Math.round(card_data.distance * 10000) / 10000).toFixed(2);
			// return dis;
			console.log(card_data.distance)
		 }
		})
}

function onCardDragMove(obj) {
      if (obj.left < -10) {
        card_data.actionName = "不喜欢";
      } else if (obj.left > 10) {
        card_data.actionName = "喜欢";
      } else {
        card_data.actionName = "";
      }
}

function onCardDragStop(obj) {
      if (card_data.actionName == "喜欢") {
      		// new Feedback('加入购物车').toast()
			Like_me()
			purChase(props.scard)
      }
	  getdistance()
	  card_data.actionName = "";
}
	
function onCardThrowDone(obj) {
      card_data.cards.splice(0, 1);
	  props.scard.splice(0,1);
}
	
function openMap(latitude,longitude,title,address){
		// new Map().openmap1()
		new Map().openmap(latitude,longitude,title,address)
		// console.log('hello1')
		new Feedback('点到了').toast()
		// console.log(props.scard[0].goods_title)
}

// 加购或立即购买
import {sku_popup} from '@/Acc-config/answer.js'
import {login_user} from '@/Acc-config/answer.js'
const db = wx.cloud.database()
import {Plublic} from '@/Acc-config/public.js'
import {onShareAppMessage,onPageScroll} from '@dcloudio/uni-app'

// onBeforeUnmount(()=>{
// 	ORDER.order.specs = []//清空之前缓存的数据
// 	ORDER.order.SPECE_STR = ''
// })

function Like_me(){
	ORDER.order.goods_id = props.scard[0]._id
	ORDER.order.goods_image = props.scard[0].cuisine_cover
	ORDER.order.goods_title = props.scard[0].cuisine_name
	ORDER.order.goods_price = props.scard[0].cuisine_price
	ORDER.order.goods_type = props.scard[0].category
}

async function purChase(sku){
	const user = wx.getStorageSync('user_infor')//取出本地缓存的用户信息
	if(!user){login_user.show = true;return false}
	// 加入购物车
	try{
		let res = await SHCART()
		new Plublic().toast(res)
	}catch(err){
		new Plublic().toast(err)
	}
}

//跳转详情页
 async function juMp(id) {
  console.log("跳转详情页")
  wx.navigateTo({
   url: `/pages/cuisine-details/details?cuisine_id=${id}`
  })
 }
</script>

<style>
view {
  box-sizing: border-box;
}

.tantanCard {
  width: 100%;
  height: 100%;
}
.zhihuCard {
  padding: 10px;
}
.cardTitle {
  font-weight: 700;
  color: #333;
  font-size: 50rpx;
  padding-left: 10px;
  /* line-height: 100%; */
}
.cardWrapper {
  text-align: left;
  /* display: flex; */
  /* line-height: 100%; */
}
.cardType{
  font-weight: 600;
  color: white;
  background-color: #f0ad4e;
  border-radius: 3px;
  font-size: 30rpx;
  padding: 2px;
  line-height: 25rpx;
}
.cardTypeView{
  padding-left: 10px;
}
.cardDetailView{
  display: flex;
  flex-direction: row;
  align-items: baseline;
  /* line-height: 25rpx; */
  /* padding-left: 10px; */
  vertical-align:top;
}
.cardAvgView{
  padding-left: 10px;	
}
.cardAvg{
  font-weight: 600;
  color: white;
  background-color: #44b348;
  border-radius: 3px;
  font-size: 30rpx;
  padding: 2px;
  line-height: 25rpx;
}
.cardDis{
  font-weight: 600;
  color: white;
  background-color: #009eff;
  border-radius: 3px;
  font-size: 30rpx;
  padding: 2px;
  line-height: 25rpx;
}
.cardDisView{
  padding-left: 10px;	
}
.flex-center-in-cube {
  width: 750rpx;
  height: 1334rpx;
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>
