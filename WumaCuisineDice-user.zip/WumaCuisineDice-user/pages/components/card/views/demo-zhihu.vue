<template>
  <view style="height: 100px">
    <fly-card
      @onDragMove="onCardDragMove"
      @onDragStop="onCardDragStop"
      @onThrowDone="onCardThrowDone"
      :cardWidth="300"
      :cardHeight="450"
      :throwTriggerDistance="100"
      dragDirection="horizontal"
      :hasShadow="true"
    >
      <template #firstCard style="width: 100%; height: 100%">
		<view v-if="cards[0]" class="zhihuCard">
		<view>
			<image :src="cards[0].image" mode="aspectFill"/>
		</view>
        <view>{{ cards[0].title }}</view>
<!--         <view>
            <view>{{ cards[0].followcount }} 关注</view>
            <view>
              <button disabled="">忽略</button>
              <button type="primary">回答</button>
            </view>
          </view> -->
        </view>
      </template>
      <template #secondCard style="width: 100%; height: 100%">
        <view v-if="cards[1]" class="zhihuCard">
		  <image
		    :src="cards[1].image"
		    style="width: 100%; height: 100%"
		    mode="aspectFill"
		  />
          <view>{{ cards[1].title }}</view>
<!--          <view>
            <view>{{ cards[1].followcount }} 关注</view>
            <view>
              <button disabled="">忽略</button>
              <button type="primary">回答</button>
            </view>
          </view> -->
        </view>
      </template>
      <template #thirdCard style="width: 100%; height: 100%">
        <view v-if="cards[2]" class="zhihuCard">
          <image
            :src="cards[2].image"
            style="width: 100%; height: 100%"
            mode="aspectFill"
          />
		  <view>{{ cards[2].title }}</view>
<!--          <view>
            <view>{{ cards[2].followcount }} 关注</view>
            <view>
              <button disabled="">忽略</button>
              <button type="primary">回答</button>
            </view>
          </view> -->
        </view>
      </template>
    </fly-card>
  </view>
</template>

<script>
import FlyCard from "../components/FlyCard.vue";
import image1 from "../assets/cat Medium.jpeg";
import image2 from "../assets/cute fox Medium.jpeg";
import image3 from "../assets/cute fox2 Medium.jpeg";
import image4 from "../assets/cute fox3 Medium.jpeg";
import image5 from "../assets/rabbit Medium.jpeg";
export default {
  components: {
    FlyCard,
  },
  data() {
    return {
      actionName: "",
	  cards: [
        {
          title: "cuisine1",
          followcount: 6,
		  image: image1,
        },
        {
          title: "cuisine2",
          followcount: 13,
		  image: image2,
        },
        {
          title:"cuisine3",
          followcount: 29,
		  image: image3,
        },
        {
          title: "cuisine4",
          followcount: 99,
		  image: image4,
        },
		{
		  title: "cuisine5",
		  followcount: 45,
		  image: image5,
		},
      ],
    };
  },
  methods: {
    onCardDragMove(obj) {},
    onCardDragStop(obj) {},
    onCardThrowDone(obj) {
      this.cards.splice(0, 1);
    },
  },
};
</script>

<style>
view {
  box-sizing: border-box;
}
.zhihuCard {
  padding: 10px;
}
.zhihuCard:nth-child(1) {
  font-size: 18px;
}
.zhihuCard > view:nth-child(2) {
  display: flex;
  position: absolute;
  width: 100%;
  left: 0px;
  bottom: 10px;
  padding: 0px 10px;
}
.zhihuCard > view:nth-child(2) > view:nth-child(1) {
  flex: 1;
  font-size: 14px;
  color: #666;
}
.zhihuCard > view:nth-child(2) > view:nth-child(2) {
  display: flex;
}
.zhihuCard > view:nth-child(2) > view:nth-child(2) > button:nth-child(2) {
  margin-left: 5px;
}
button {
  height: 24px;
  line-height: 24px;
  font-size: 12px;
}
</style>
