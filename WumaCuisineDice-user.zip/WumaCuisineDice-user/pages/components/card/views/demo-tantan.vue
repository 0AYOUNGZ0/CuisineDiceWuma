<template>
  <view class="flex-center-in-cube">
	<view
      v-if="actionName != ''"
      style="
        color: #fff;
        background: rgba(0, 0, 0, 0.9);
        padding: 10px 20px;
        font-size: 24px;
        position: absolute;
		border-radius: 5px;
        z-index: 999;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
      "
    >
      {{ actionName }}
    </view>
    <fly-card
      @onDragMove="onCardDragMove"
      @onDragStop="onCardDragStop"
      @onThrowDone="onCardThrowDone"
      :cardWidth="640"
      :cardHeight="920"
      :throwTriggerDistance="100"
      dragDirection="all"
      :hasShadow="true"
	  :borderRadius="18"
	  :hasBorder="false"
    >
      <template #firstCard style="width: 100%; height: 100%;">
        <view v-if="cards[0]" class="tantanCard" @click="openMap(cards[0].latitude,cards[0].longitude,cards[0].title,cards[0].address)">
          <image
            :src="cards[0].image"
            style="width: 100%; height: 80%"
            mode="aspectFill"
          />
		  <view class="cardWrapper">
			  <view>
				  <text class="cardTitle">
					  {{cards[0].title}}
				  </text>
			  </view>
			  <view class="cardDetailView">
				  <view class="cardTypeView">
					  <text class="cardType">
						  {{cards[0].type}}
					  </text>
				  </view>
				  <view class="cardAvgView">
					  <text class="cardAvg">
						  人均{{cards[0].avgPrice}}¥
					  </text>
				  </view>
				  <view class="cardDisView">
					  <text class="cardDis">
						  {{cards[0].distance}}
					  </text>
				  </view>
			  </view>
		  </view>
        </view>
      </template>
      <template #secondCard style="width: 100%; height: 100%" >
        <view v-if="cards[1]" class="tantanCard" @click="openMap(cards[1].latitude,cards[1].longitude,cards[1].title,cards[1].address)">
          <image
            :src="cards[1].image"
            style="width: 100%; height: 80%"
            mode="aspectFill"
          />
		  <view class="cardWrapper">
			  <view>
				  <text class="cardTitle">
					  {{cards[1].title}}
				  </text>
			  </view>
			  <view class="cardDetailView">
				  <view class="cardTypeView">
					  <text class="cardType">
						  {{cards[1].type}}
					  </text>
				  </view>
				  <view class="cardAvgView">
					  <text class="cardAvg">
						  人均{{cards[1].avgPrice}}¥
					  </text>
				  </view>
				  <view class="cardDisView">
					  <text class="cardDis">
						  {{cards[1].distance}}
					  </text>
				  </view>
			  </view>
		  </view>
        </view>
      </template>
      <template #thirdCard style="width: 100%; height: 100%">
        <view v-if="cards[2]" class="tantanCard" @click="openMap(cards[2].latitude,cards[2].longitude,cards[2].title,cards[2].address)">
          <image
            :src="cards[2].image"
            style="width: 100%; height: 80%"
            mode="aspectFill"
          />
		  <view class="cardWrapper">
			  <view>
				  <text class="cardTitle">
					  {{cards[2].title}}
				  </text>
			  </view>
			  <view class="cardDetailView">
				  <view class="cardTypeView">
					  <text class="cardType">
						  {{cards[2].type}}
					  </text>
				  </view>
				  <view class="cardAvgView">
					  <text class="cardAvg">
						  人均{{cards[2].avgPrice}}¥
					  </text>
				  </view>
				  <view class="cardDisView">
					  <text class="cardDis">
						  {{cards[2].distance}}
					  </text>
				  </view>
			  </view>
		  </view>
        </view>
      </template>
    </fly-card>
  </view>
</template>

<script>
import FlyCard from "../components/FlyCard.vue";
import image1 from "../assets/cat Medium.jpeg";
import image2 from "../assets/cute fox Medium.jpeg";
import image3 from "../assets/cute fox2 Medium.jpeg";
import image4 from "../assets/cute fox3 Medium.jpeg";
import image5 from "../assets/rabbit Medium.jpeg";

import {Map,Feedback} from '../../../../Acc-config/map-view.js'	
// function openMap(){
// 	new Map().openmap1()
// 	// console.log('hello1')
// 	new Feedback('点到了').toast()
// }

export default {
  components: {
    FlyCard,
  },
  data() {
    return {
      actionName: "",
      cards: [
        {
          image: image1,
		  title: "陈辉鱼圆",
		  type: "小吃面食",
		  avgPrice: "30",
		  distance: "245m",
		  longitude: 120.667877,
		  latitude: 28.018295,
		  address: "超人气韩料店 芝士给的很大方，满满的能拉丝  弄堂小店",
        },
        {
          image: image2,
		  title: "西施豆腐",
		  type: "小吃面食",
		  avgPrice: "7",
		  distance: "1.2km",
		  longitude: 120.668138,
		  latitude: 28.017316,
		  address: "装修很有特色，复古小巷风 个人感觉肉质还可以 价格挺划算",
        },
        {
          image: image3,
		  title: "童姥阁北京烤鸭",
		  type: "北京烤鸭",
		  avgPrice: "88",
		  distance: "534m",
		  longitude: 120.668884,
		  latitude: 28.018648,
		  address: "装修很有特色，复古小巷风",
        },
        {
          image: image4,
          title: "酒隐食肆日式融合料理",
		  type: "日本料理",
		  avgPrice: "94",
		  distance: "2.4km",
		  longitude: 120.664861,
		  latitude: 28.016544,
		  address: "装修很有特色，复古小巷风",
        },
        {
          image: image5,
          title: "卤枝一家老成都串串香",
		  type: "特色小吃",
		  avgPrice: "20",
		  distance: "3.5km",
		  longitude: 120.664945,
		  latitude: 28.017178,
		  address: "装修很有特色，复古小巷风",
        },
      ],
    };
  },
  methods: {
    onCardDragMove(obj) {
      if (obj.left < -10) {
        this.actionName = "不喜欢";
      } else if (obj.left > 10) {
        this.actionName = "喜欢";
      } else {
        this.actionName = "";
      }
    },
    onCardDragStop(obj) {
      this.actionName = "";
    },
    onCardThrowDone(obj) {
      this.cards.splice(0, 1);
    },
	openMap(latitude,longitude,title,address){
		// new Map().openmap1()
		new Map().openmap(latitude,longitude,title,address)
		// console.log('hello1')
		new Feedback('点到了').toast()
	}
  },
};
</script>

<style>
view {
  box-sizing: border-box;
}

.tantanCard {
  width: 100%;
  height: 100%;
}
.zhihuCard {
  padding: 10px;
}
.cardTitle {
  font-weight: 700;
  color: #333;
  font-size: 50rpx;
  padding-left: 10px;
  /* line-height: 100%; */
}
.cardWrapper {
  text-align: left;
  /* display: flex; */
  /* line-height: 100%; */
}
.cardType{
  font-weight: 600;
  color: white;
  background-color: #f0ad4e;
  border-radius: 3px;
  font-size: 30rpx;
  padding: 2px;
  line-height: 25rpx;
}
.cardTypeView{
  padding-left: 10px;
}
.cardDetailView{
  display: flex;
  flex-direction: row;
  align-items: baseline;
  /* line-height: 25rpx; */
  /* padding-left: 10px; */
  vertical-align:top;
}
.cardAvgView{
  padding-left: 10px;	
}
.cardAvg{
  font-weight: 600;
  color: white;
  background-color: #44b348;
  border-radius: 3px;
  font-size: 30rpx;
  padding: 2px;
  line-height: 25rpx;
}
.cardDis{
  font-weight: 600;
  color: white;
  background-color: #009eff;
  border-radius: 3px;
  font-size: 30rpx;
  padding: 2px;
  line-height: 25rpx;
}
.cardDisView{
  padding-left: 10px;	
}
.flex-center-in-cube {
  width: 750rpx;
  height: 1334rpx;
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>
