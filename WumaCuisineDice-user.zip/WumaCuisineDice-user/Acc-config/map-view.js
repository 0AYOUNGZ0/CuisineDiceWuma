
//open weixin-map
class Map{
	// constructor(latitude,longitude,scale=18){
	// 	this.latitude = latitude
	// 	this.longitude = longitude
	// 	this.scale = scale
	// }
	constructor(){}
	
	// openmap2(latitude,longitude,destination){
	// 	wx.
	// }
	//show map
	openmap(latitude,longitude,name,scale=18){
		console.log('hello2')
		wx.openLocation({
			latitude,
			longitude,
			name,
			scale: 18
		})
		// wx.getLocation({
		 // type: 'gcj02', //返回可以用于 wx.openLocation 的经纬度
		 // type: 'wgs84',
	 // success: function (res) {
	 //   const latitude = res.latitude
	 //   const longitude = res.longitude
		// console.log(latitude);
		// console.log(longitude);
		// console.log('hello!！！！')
	 //   wx.openLocation({
		//  latitude,
		//  longitude,
		//  scale: 18
	 //   })
	 // }
		// })
	}
	openmap1(){
		wx.getLocation({
		 type: 'gcj02', //返回可以用于 wx.openLocation 的经纬度
		 // type: 'wgs84',
		 success (res) {
		   const latitude = res.latitude
		   const longitude = res.longitude
			console.log(latitude);
		    console.log(longitude);
			console.log('hello!')
		   wx.openLocation({
		     latitude,
		     longitude,
			 name: "名字在这",
			 address: "超人气韩料店 芝士给的很大方，满满的能拉丝  弄堂小店",
		     scale: 3
		   })
		 }
		})
	}
}

class Feedback{
	constructor(title,icon="error"){
		this.title = title
		this.icon = icon
	}
	
	// pop up toast 
	toast(){
		wx.showToast({
		  title: this.title,
		  icon:this.icon,
		  mask:true,
		  duration: 800
		})
	}
}

export {Map,Feedback}