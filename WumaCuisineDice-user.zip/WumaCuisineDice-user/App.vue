<script>
	export default {
		onLaunch: function() {
			wx.cloud.init({
			  env: 'cloud1-8gkvfpn7b81453b6',
			  traceUser: true,
			})
		},
	}
</script>

<style>
	/*每个页面公共css */
</style>
